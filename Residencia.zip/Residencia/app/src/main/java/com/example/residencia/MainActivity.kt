package com.example.residencia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.example.residencia.alumnos.Alumno
import com.example.residencia.alumnos.AlumnoDatabase
import com.example.residencia.databinding.ActivityMainBinding
import com.example.residencia.fragments.Login
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private val AlumnoDB by lazy { AlumnoDatabase.getDatabase(this).alumDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Abrir el fragmento "Login"
        val transaccion = supportFragmentManager.beginTransaction()
        val fragmento = Login()
        transaccion.replace(R.id.container, fragmento)
        transaccion.addToBackStack(null)
        transaccion.commit()
    }
}