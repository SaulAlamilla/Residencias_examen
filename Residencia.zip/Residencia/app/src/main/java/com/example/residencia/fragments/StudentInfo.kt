package com.example.residencia.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.residencia.R
import com.example.residencia.alumnos.Alumno

private const val ALUMNO = "alumno"
class StudentInfo : Fragment() {
    private var alumno: Alumno? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            alumno = it.getSerializable(ALUMNO) as Alumno
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_student_info, container, false)
        val nombre = view.findViewById<TextView>(R.id.tv_Nombre)
        nombre.text = alumno?.nombres
        return view
    }
    companion object {
        @JvmStatic
        fun newInstance(alumno: Alumno) =
            StudentInfo().apply {
                arguments = Bundle().apply {
                    putSerializable(ALUMNO,alumno)
                }
            }
    }
}