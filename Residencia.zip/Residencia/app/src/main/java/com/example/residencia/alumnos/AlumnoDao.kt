package com.example.residencia.alumnos

import androidx.room.*
import com.example.residencia.alumnos.Alumno

@Dao
interface AlumnoDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAlumno(alumno: Alumno)

    @Query("SELECT * FROM alumnos")
    suspend fun getAlumnos(): List<Alumno>

    @Query("SELECT * FROM alumnos WHERE numero_de_control LIKE :numero_de_control AND contrasena LIKE :contrasena")
    suspend fun logInAlumno(numero_de_control:String,contrasena:String) : Alumno?
}