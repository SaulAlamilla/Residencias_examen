package com.example.residencia.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.lifecycleScope
import com.example.residencia.R
import com.example.residencia.alumnos.Alumno
import com.example.residencia.alumnos.AlumnoDatabase
import com.example.residencia.proyectos.Proyecto
import com.example.residencia.proyectos.ProyectoDatabase
import kotlinx.coroutines.launch

class NewProject : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_new_project, container, false)

        val ProyectoDB by lazy { ProyectoDatabase.getDatabase(context).proyectoDao() }

        val btnAdd = view.findViewById<Button>(R.id.btnNewProject)
        btnAdd.setOnClickListener {
            lifecycleScope.launch {
                var nombre = view.findViewById<EditText>(R.id.txtNombreProyecto).text.toString()
                var descripcion = view.findViewById<EditText>(R.id.txtDescripcion).text.toString()
                var area = view.findViewById<EditText>(R.id.txtArea).text.toString()
                var alumnosRequeridos = view.findViewById<EditText>(R.id.txtAlumnosRequeridos).text.toString()
                var encargado = view.findViewById<EditText>(R.id.txtEncargado).text.toString()

                ProyectoDB.addProject(Proyecto(0, nombre, descripcion, area, alumnosRequeridos, encargado))
            }

            var mFragmentTransaction: FragmentTransaction = parentFragmentManager.beginTransaction()
            var fragList = Projects()

            mFragmentTransaction.replace(R.id.container, fragList)
            mFragmentTransaction.addToBackStack(null)
            mFragmentTransaction.commit()
        }

        return view
    }
}