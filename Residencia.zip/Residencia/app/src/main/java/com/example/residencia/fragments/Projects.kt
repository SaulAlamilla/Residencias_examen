package com.example.residencia.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.example.residencia.R
import com.example.residencia.alumnos.Alumno
import com.example.residencia.proyectos.ProjectAdapter
import com.example.residencia.proyectos.Proyecto
import com.example.residencia.proyectos.ProyectoDatabase
import kotlinx.coroutines.launch

class Projects : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_projects, container, false)

        val ProyectoDB by lazy { ProyectoDatabase.getDatabase(context).proyectoDao() }

        lifecycleScope.launch {
            var listProjects: List<Proyecto> = ProyectoDB.getProjects()

            val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerId)
            recyclerView.adapter = ProjectAdapter(context, listProjects)
            recyclerView.setHasFixedSize(true)
        }

        val addProject = view.findViewById<Button>(R.id.btnAddProject)
        addProject.setOnClickListener {
            var mFragmentTransaction: FragmentTransaction = parentFragmentManager.beginTransaction()
            var fragList = NewProject()

            mFragmentTransaction.replace(R.id.container, fragList)
            mFragmentTransaction.addToBackStack(null)
            mFragmentTransaction.commit()
        }

        return view
    }
}